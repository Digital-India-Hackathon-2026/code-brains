package com.codebrains.muleguard.repositories;

import com.codebrains.muleguard.models.PredictionRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PredictionRecordRepository extends JpaRepository<PredictionRecord, Long> {

    List<PredictionRecord> findByRiskLevel(@Param("riskLevel") String riskLevel);

    List<PredictionRecord> findTop50ByOrderByCreatedAtDesc();
}
