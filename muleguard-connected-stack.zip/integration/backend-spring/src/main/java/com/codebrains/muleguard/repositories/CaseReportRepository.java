package com.codebrains.muleguard.repositories;

import com.codebrains.muleguard.models.CaseReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CaseReportRepository extends JpaRepository<CaseReport, String> {
    // Spring Boot automatically writes all the SQL for saving and finding reports just by extending JpaRepository!
}